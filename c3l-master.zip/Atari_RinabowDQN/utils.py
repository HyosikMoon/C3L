import torch
import numpy as np
import random

def set_seed_everywhere(seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)


class DBSCAN:
    def __init__(self, eps=1.0, min_samples=5, tolerance_eps=0.1, tolerance_samples=0.1, metric='euclidean', batch_size=32):
        self.eps = eps
        self.min_samples = min_samples
        self.tolerance_eps = tolerance_eps
        self.tolerance_samples = tolerance_samples
        self.metric = metric
        self.batch_size = batch_size
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.labels = None
        self.centroids = None

    def pairwise_distance_matrix(self, x, y=None):
        y = x if y is None else y
        dists = torch.cdist(x, y)
        return dists

    def find_neighbors(self, dist_matrix):
        neighbors = dist_matrix < self.eps
        return neighbors

    def fit(self, X):
        X = X.to(self.device)
        
        dist_matrix = self.pairwise_distance_matrix(X)
        # Set eps based on the distance of the k-th nearest neighbor
        k = int(self.batch_size * self.tolerance_eps if self.batch_size else int(X.size(0) * self.tolerance_eps))
        k_dist, _ = torch.topk(dist_matrix, k, dim=1, largest=False, sorted=True)
        self.eps = k_dist[:, -1].mean().item()
        self.min_samples = int(self.batch_size * self.tolerance_samples)
        neighbors = self.find_neighbors(dist_matrix)
            
        labels = torch.full((X.shape[0],), -1, dtype=torch.long, device=self.device)
        cluster_id = 0

        for idx in range(X.shape[0]):
            if labels[idx] != -1:
                continue

            idx_neighbors = neighbors[idx]
            if torch.sum(idx_neighbors) < self.min_samples:
                # Mark as noise initially
                labels[idx] = -2
            else:
                labels[idx] = cluster_id
                labels[idx_neighbors] = cluster_id
                cluster_id += 1

        # Assign unique labels to noise points
        noise_label_start = cluster_id  # Start labeling noise points after the last cluster ID
        for i, label in enumerate(labels):
            if label == -2:
                labels[i] = noise_label_start
                noise_label_start += 1

        self.labels = labels
        self.centroids = self.compute_centroids(X, labels)

        return self.centroids, self.labels 
    
    def compute_centroids(self, X, labels):
        unique_labels = labels.unique(sorted=True)
        centroids = []

        for label in unique_labels:
            mask = (self.labels == label)
            cluster_points = X[mask]
            centroid = cluster_points.mean(dim=0, keepdim=True)
            centroids.append(centroid)

        return torch.cat(centroids, dim=0)
    
    def get_labels(self):
        return self.labels if self.labels is not None else None

    def get_centroids(self):
        return self.centroids if self.centroids is not None else None
    
class KMeansClustering:
    def __init__(self, init_centroids, num_iterations=100):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.init_centroids = init_centroids
        self.num_iterations = num_iterations

    def fit(self, X, tolerance=1e-4):
        n_clusters = len(self.init_centroids)
        n_iters = self.num_iterations

        # Randomly initialize centroids
        X = X.to(self.device)
        centroids = self.init_centroids.to(self.device)

        for _ in range(n_iters):
            # Assign clusters
            distances = torch.cdist(X, centroids)
            labels = torch.argmin(distances, axis=1)

            # Update centroids
            new_centroids = []
            for i in range(n_clusters):
                assigned_points = X[labels == i]
                if len(assigned_points) == 0:
                    random_idx = torch.randint(0, X.size(0), (1,))
                    new_centroid = X[random_idx]
                else:
                    new_centroid = assigned_points.mean(0, keepdim=True)
                new_centroids.append(new_centroid)

            new_centroids = torch.cat(new_centroids, dim=0)

            # Check for convergence
            centroid_shift = torch.norm(new_centroids - centroids, dim=1).sum()
            if centroid_shift < tolerance:
                break

            centroids = new_centroids

        return centroids, labels