[C3L: Cluster Centroids Contrastive Learning for High-Level Semantic-Aware Reinforcement Learning]

Our code is based on [CURL](https://github.com/MishaLaskin/curl). The official implementations of [C3L] will also be available at the following links after peer review: ---- for the DeepMind Control experiments and ---- for the Atari experiments.

## Installation for DMControl

```
Libraries (Required libraries can be different based on the settings.)
- conda, python (3.11.5)
- gym (0.17.3)
- git
- pytorch, https://pytorch.org/
- dmc2gym, pip install git+https://github.com/denisyarats/dmc2gym.git (change np.int(~) -> int(~) in the wrapper.py file in cf. C:\Users\owner\anaconda3\envs\gymenv\Lib\site-packages\dmc2gym)
- scikit-learn
- matplotlib
- scikit-image
- termcolor
- tensorboard
```

## Instructions
To train a C3L agent on the `cheetah, run` task using image-based observations, configure the environments and hyperparameters in the `train.py` file, then execute the `train.py` file.

In your console, you should observe printouts similar to the following:
```
| train | E: 0 | S: 6000 | D: 513.1 s | R: 0.0000 | BR: 0.0000 | A_LOSS: 0.0000 | CR_LOSS: 0.0000 | C3L_LOSS: 0.0000
| train | E: 25 | S: 6500 | D: 389.9 s | R: 83.2496 | BR: 0.1873 | A_LOSS: -9.1030 | CR_LOSS: 0.1168 | C3L_LOSS: 1.9664
| train | E: 27 | S: 7000 | D: 0.0 s | R: 29.1004 | BR: 0.2005 | A_LOSS: -9.8642 | CR_LOSS: 0.1332 | C3L_LOSS: 2.1396
| eval | S: 7000 | ER: 124.3240
```

Log abbreviation mapping:
```
train - training episode
E - total number of episodes 
S - total number of environment steps
D - duration in seconds to train 1 episode
R - mean episode reward
BR - average reward of sampled batch
A_LOSS - average loss of actor
CR_LOSS - average loss of critic
C3L_LOSS - average loss of the C3L encoder
```
